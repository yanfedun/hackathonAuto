import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Steps {

    WebDriver driver;

    @Before
    public void setUp(){
        driver = new ChromeDriver();
    }

    @Given("^I open site$")
    public void iOpenSite() {

        driver.get("http://www.i.ua/");
        driver.manage().window().getPosition();
    }

    @When("^I login$")
    public void iLogin() {
        driver.findElement(By.cssSelector("[name=\"login\"]")).sendKeys("autotest777@i.ua");
        driver.findElement(By.cssSelector("[name=\"pass\"]")).sendKeys("yan731731731");
        driver.findElement(By.cssSelector("[tabindex=\"5\"]")).click();
    }

    @And("^I send mail$")
    public void iSendMail() {
        driver.findElement(By.cssSelector("[href=\"/compose/1252334677/\"]")).click();
        driver.findElement(By.cssSelector("#to")).sendKeys("autotest777@i.ua");
        driver.findElement(By.cssSelector("[name=\"subject\"]")).sendKeys("HI!");
        driver.findElement(By.cssSelector("#text")).sendKeys("HI!");
        driver.findElement(By.cssSelector("[name=\"send\"]")).click();
    }
}
